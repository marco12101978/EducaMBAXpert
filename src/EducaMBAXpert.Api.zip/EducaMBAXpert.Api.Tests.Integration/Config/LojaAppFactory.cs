﻿using EducaMBAXpert.Pagamentos.Data.Context;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.IO;
using System;
using System.Linq;

namespace EducaMBAXpert.Api.Tests.Integration.Config
{
    public class LojaAppFactory<TProgram> : WebApplicationFactory<TProgram> where TProgram : class
    {
        protected override IHost CreateHost(IHostBuilder builder)
        {
            builder.UseEnvironment("Test");
            return base.CreateHost(builder);
        }

        //protected override void ConfigureWebHost(IWebHostBuilder builder)
        //{
        //    builder.ConfigureServices(services =>
        //    {
        //        // Remove qualquer PagamentoContext anterior
        //        var descriptor = services.SingleOrDefault(
        //            d => d.ServiceType == typeof(DbContextOptions<PagamentoContext>));

        //        if (descriptor != null)
        //            services.Remove(descriptor);

        //        // Caminho para o banco SQLite físico
        //        var dbPath = Path.Combine(AppContext.BaseDirectory, "TestDatabase.db");

        //        // Adiciona PagamentoContext com SQLite físico
        //        services.AddDbContext<PagamentoContext>(options =>
        //        {
        //            options.UseSqlite($"Data Source={dbPath}");
        //        });

        //        // Garante que o banco e schema estejam criados
        //        var sp = services.BuildServiceProvider();
        //        using (var scope = sp.CreateScope())
        //        {
        //            var db = scope.ServiceProvider.GetRequiredService<PagamentoContext>();
        //            db.Database.EnsureDeleted(); // Limpa antes de cada execução
        //            db.Database.EnsureCreated(); // Cria novamente
        //        }
        //    });
        //}

    }
}
